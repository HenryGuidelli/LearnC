#include <stdio.h>

int main() {

	printf("Hello Word!\n");

	return 0;

}
