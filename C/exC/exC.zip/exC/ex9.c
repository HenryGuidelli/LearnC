#include <stdio.h>

void main(){
    
    int b, h, A;

	printf("Valor da base: ");
	scanf("%d", &b);

	printf("Valor da altura: ");
        scanf("%d", &h);

	A = (b * h)/2;

	printf("\nArea = %d\n", A);

}
